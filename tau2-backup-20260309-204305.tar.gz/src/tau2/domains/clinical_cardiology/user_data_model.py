"""User Data Model for Clinical Domains

This module provides a shared user data model for all clinical domains.
"""

from typing import Optional

from pydantic import Field

from tau2.environment.db import DB


class ClinicalUserDB(DB):
    """Database for clinical user information.

    This stores user/patient information that is used during the consultation.
    """

    name: Optional[str] = Field(
        None,
        description="The patient's name",
    )
    mrn: Optional[str] = Field(
        None,
        description="Medical Record Number",
    )
    age: Optional[int] = Field(
        None,
        description="The patient's age",
    )
    gender: Optional[str] = Field(
        None,
        description="The patient's gender",
    )
