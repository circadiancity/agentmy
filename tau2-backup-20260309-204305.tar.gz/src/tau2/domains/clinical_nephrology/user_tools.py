"""User Tools for Clinical Nephrology Domain

This module provides user tools for simulating patient interactions
in the clinical nephrology domain.
"""

from tau2.domains.clinical_nephrology.user_data_model import ClinicalUserDB
from tau2.environment.toolkit import ToolKitBase


class NephrologyUserTools(ToolKitBase):
    """
    Provides methods to simulate user/patient actions and state
    in the clinical nephrology domain.
    """

    db: ClinicalUserDB

    def __init__(self, db: ClinicalUserDB):
        """
        Initializes the nephrology user tools.

        Args:
            db: The clinical user database containing patient information.
        """
        super().__init__(db)

    def set_user_info(
        self,
        name: str,
        mrn: str,
        age: int = None,
        gender: str = None,
    ) -> str:
        """
        Sets the patient's information for the consultation.

        Args:
            name: The patient's name.
            mrn: Medical Record Number.
            age: The patient's age (optional).
            gender: The patient's gender (optional).

        Returns:
            A confirmation message with the patient information.
        """
        self.db.name = name
        self.db.mrn = mrn
        self.db.age = age
        self.db.gender = gender

        parts = [f"Name: {name}", f"MRN: {mrn}"]
        if age is not None:
            parts.append(f"Age: {age}")
        if gender is not None:
            parts.append(f"Gender: {gender}")

        return f"Patient information set:\n" + "\n".join(parts)
